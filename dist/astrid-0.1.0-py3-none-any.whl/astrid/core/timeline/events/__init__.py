"""Timeline event schema namespace."""
