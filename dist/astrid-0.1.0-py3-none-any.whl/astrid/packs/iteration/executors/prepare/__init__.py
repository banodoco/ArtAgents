"""Iteration preparation executor."""
