"""Dataset-build reporting helpers."""
