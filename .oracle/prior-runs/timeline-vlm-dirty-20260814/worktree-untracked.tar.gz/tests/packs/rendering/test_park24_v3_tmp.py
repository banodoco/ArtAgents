from pathlib import Path

def test_render_v3(tmp_projects_root):
    from astrid.core.timeline.snapshot import acquire_snapshot
    from astrid.packs.rendering.executors.timeline_visualize.model import build_model
    from astrid.packs.rendering.executors.timeline_visualize.navigation import build_identity_map
    from astrid.packs.rendering.executors.timeline_visualize.scope import select_scope
    from astrid.packs.rendering.executors.timeline_visualize.layout import layout_timeline
    from astrid.packs.rendering.executors.timeline_visualize.render_png import render_page_png
    import shutil
    from tests.packs.rendering.test_timeline_visualize_gate_park24 import _prepare_project, _write_verified_media
    project_root, timeline = _prepare_project(tmp_projects_root, "v3")
    _write_verified_media(project_root, timeline, "v3")
    snap = acquire_snapshot(timeline, project_slug="v3", project_root=project_root)
    m = build_model(snap, project_root=project_root)
    im = build_identity_map(m, root_sns=m.snapshot_sns, timeline_uuid=m.timeline_uuid, timeline_ulid=m.timeline_ulid)
    out = Path("/tmp/park24_views")
    if out.exists():
        shutil.rmtree(out)
    out.mkdir()
    sc = select_scope(m, kind="timeline")
    for i, page in enumerate(layout_timeline(m, im, sc, layout="time-scaled"), 1):
        (out / f"root-pg{i}.png").write_bytes(render_page_png(page, scale=1))
    # CL23 focus (the wide card) label check
    for page in layout_timeline(m, im, sc, layout="time-scaled"):
        for o in page.objects:
            if o.kind in ("clip", "continuation"):
                print(o.display_id, o.kind, "label:", o.label, flush=True)
    media = Path("tests/fixtures/timeline_visualize/park24_media")
    for key, tag in (("park-frame-03", "orig-cl03"), ("park-frame-09", "orig-cl09"), ("park-frame-16", "orig-cl16")):
        shutil.copyfile(media / f"{key}.png", out / f"{tag}.png")
    print("SAVED", sorted(p.name for p in out.glob("*.png")), flush=True)
